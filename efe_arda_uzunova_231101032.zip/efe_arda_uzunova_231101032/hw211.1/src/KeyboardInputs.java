import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;



public class KeyboardInputs implements KeyListener {

	private GamePanel gamePanel;

	public KeyboardInputs(GamePanel gamePanel) {
		this.gamePanel = gamePanel;
	}
	@Override
	public void keyTyped(KeyEvent e) {
	}
	@Override
	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
			case KeyEvent.VK_W:
				gamePanel.getGame().getPlayer().setJump(true);
				break;
			case KeyEvent.VK_A:
				gamePanel.getGame().getPlayer().setLeft(true);
				gamePanel.getGame().getPlayer().setDirection(Constants.Directions.LEFT);
				break;
			case KeyEvent.VK_D:
				gamePanel.getGame().getPlayer().setRight(true);
				gamePanel.getGame().getPlayer().setDirection(Constants.Directions.RIGHT);
				break;
			case KeyEvent.VK_1:
				gamePanel.getGame().getPlayer().setColor(Color.red);
				gamePanel.getGame().getPlayer().setJumpSpeed(- 2.25f * Game.SCALE);
				break;
			case KeyEvent.VK_2:
				gamePanel.getGame().getPlayer().setColor(Color.blue);
				gamePanel.getGame().getPlayer().setJumpSpeed(- 2.25f * Game.SCALE);
				break;
			case KeyEvent.VK_3:
				gamePanel.getGame().getPlayer().setColor(Color.magenta);
				gamePanel.getGame().getPlayer().setJumpSpeed(- 3.5f * Game.SCALE);
				break;
			case KeyEvent.VK_SPACE:
				gamePanel.getGame().getPlayer().setShoot(true);
				break;
			case KeyEvent.VK_P:
				gamePanel.getGame().switchPause();
				break;
			case KeyEvent.VK_K:
				gamePanel.getGame().save();
				break;
		}
	}
	@Override
	public void keyReleased(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_W:
			gamePanel.getGame().getPlayer().setJump(false);
			break;
		case KeyEvent.VK_A:
			gamePanel.getGame().getPlayer().setLeft(false);
			break;
		case KeyEvent.VK_D:
			gamePanel.getGame().getPlayer().setRight(false);
			break;
		case KeyEvent.VK_SPACE:
			gamePanel.getGame().getPlayer().setShoot(false);
			break;
		}
	}


}
