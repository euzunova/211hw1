import java.awt.*;

public class Gold extends Entity{
    public Gold(float x, float y, int width, int height, Color color,Game game) {
        super(x+Game.TILES_SIZE/2-width/2, y+Game.TILES_SIZE/2-height/2, width, height, color,game);
    }

    @Override
    public void update(){

        if (HelpMethods.DoesCollide(this,game.getPlayer())){
            dissappear();
            game.addPoints(5);
        }

    }
    @Override
    public void render(Graphics g) {
        g.setColor(color);
        g.fillRect((int) x,(int) y,width,height);
    }

    private void dissappear(){
        game.RemoveFromArrayLists(this);
    }

}
