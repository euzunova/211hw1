import java.awt.*;
public class Player extends Entity {
	private boolean left, right, jump, shoot;
	private int direction = Constants.Directions.RIGHT;
	private float jumpSpeed = - 2.25f * Game.SCALE;
	private float fallSpeedAfterCollision = 0.5f*Game.SCALE;
	private int updatesForShoot=0;

	public Player(float x, float y,int width,int height,Color color,Game game) {
		super(x, y,width,height,color,game);
		setEntitySpeed(2.0f);			//SET PLAYERSPEED
	}

	public void update() {
		if (color==Color.RED && HelpMethods.onBlue(hitbox,Level.getLeveldata()))
			game.restart();
		if (color==Color.BLUE && HelpMethods.onRed(hitbox,Level.getLeveldata()))
			game.restart();
		if (color==Color.MAGENTA && (HelpMethods.onRed(hitbox,Level.getLeveldata()) || HelpMethods.onBlue(hitbox,Level.getLeveldata())))
			game.restart();
		if (HelpMethods.CollidedEnemy(this,game.getEnemies())!=null)
			game.restart();
		updateHitbox();
		updatePos();

	}
	public void render(Graphics g) {
		g.setColor(color);
		g.fillRect( (int) x, (int) y, width, height);
	}
	private void updatePos() {
		updatesForShoot++;
		float xSpeed = 0;
		Platform collidedPlatform = HelpMethods.CollidedPlatform(this,game.getPlatforms());

		if (collidedPlatform!=null){
			xSpeed=collidedPlatform.getxSpeed();
			airSpeed=collidedPlatform.getySpeed();
		}

		if (jump) {
			jump();
		}

		if (shoot){
			if (updatesForShoot>30){
				shoot();
				updatesForShoot=0;
			}

		}

		if (!left && !right && !inAir) {
			return;
		}

		if (left)
			xSpeed -= entitySpeed;
		if (right)
			xSpeed += entitySpeed;

		if(!inAir){
			if(!HelpMethods.IsEntityOnFloor(hitbox,lvlData)){
				inAir = true;
			}
		}


		if (inAir) {
			if (HelpMethods.CanMoveHere(hitbox.x, hitbox.y + airSpeed, hitbox.width, hitbox.height, lvlData)) {
				y += airSpeed;
				airSpeed += gravity;
				updateXPos(xSpeed);
			}

			else {
				y = (int) HelpMethods.GetEntityYPos(hitbox, airSpeed);

				if (airSpeed > 0)
					resetInAir();
				else
					airSpeed = fallSpeedAfterCollision;

				updateXPos(xSpeed);
			}
		}else
			updateXPos(xSpeed);
	}
	private void jump(){
		if(inAir && HelpMethods.CollidedPlatform(this,game.getPlatforms())==null)
			return;
		inAir = true;
		airSpeed = jumpSpeed;
	}
	private void shoot(){
		if (color!=Color.magenta)
			game.addToArrayLists(new Bullet(x,y,Game.TILES_SIZE/6,Game.TILES_SIZE/6,color,direction,game));
	}
	private void resetInAir() {
		inAir = false;
		airSpeed = 0;
	}
	private void updateXPos(float xSpeed) {
		if (HelpMethods.CanMoveHere(x+xSpeed,y,width,height,lvlData)){
			this.x += xSpeed;
		}
	}
	public void resetDirBooleans() {
		left = false;
		right = false;
	}
	public void setJump(boolean jump) {
		this.jump = jump;
	}
	public void setShoot(boolean shoot){
		this.shoot = shoot;
	}
	public void setJumpSpeed(float jumpSpeed) {
		this.jumpSpeed = jumpSpeed;
	}
	public void setLeft(boolean left) {
		this.left = left;
	}
	public void setRight(boolean right) {
		this.right = right;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	public void setDirection(int direction) {
		this.direction = direction;
	}
}
