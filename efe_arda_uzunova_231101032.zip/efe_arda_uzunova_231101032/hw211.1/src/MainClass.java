import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class MainClass  {

	public static void main(String[] args) {
		Game game = null;

		if (args.length>0){
			try {
				ObjectInputStream ois = new ObjectInputStream(new FileInputStream(args[0]));
				game = (Game) ois.readObject();
			} catch (Exception e) {
				e.printStackTrace();
			}
			game.initPanel();
			game.startGameLoop();

		}
		else {
			game = new Game();
		}


	}


}
