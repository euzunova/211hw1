import java.awt.*;

public class Bullet extends Entity{
    private float xSpeed;
    public Bullet(float x, float y, int width, int height, Color color,int direction, Game game) {
        super(x, y, width, height, color, game);
        entitySpeed = 3.5f; //BULLET SPEED
        xSpeed = entitySpeed*direction;
    }

    public void update() {
        updatePos();
        updateHitbox();
    }
    public void render(Graphics g) {
        g.setColor(color);
        g.fillRect( (int) x, (int) y, width, height);
    }
    private void updatePos(){
        updateXPos(xSpeed);
    }
    private void updateXPos(float xSpeed) {
        if (HelpMethods.CanMoveHere(x+xSpeed,y,width,height,lvlData) && HelpMethods.CollidedEnemy(this,game.getEnemies())==null ){
            this.x += xSpeed;
        }else hitObject();
    }
    private void hitObject(){
        Enemy enemy = HelpMethods.CollidedEnemy(this, game.getEnemies());
        if (enemy!=null)
            enemy.getHit(this.color);
        dissappear();
    }
    private void dissappear(){
        game.RemoveFromArrayLists(this);
    }

}
