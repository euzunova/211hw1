import java.awt.*;

public class Platform extends Entity{
    private int bound1x,bound1y,bound2x,bound2y;
    private double periodOnUpdates;
    private float xSpeed,ySpeed;

    public Platform(float x, float y, int width, int height, Color color, int bound1x, int bound1y, int bound2x, int bound2y, double period,Game game) {
        super(x, y, width, height, color,game);
        this.bound1x = bound1x;
        this.bound1y = bound1y;
        this.bound2x = bound2x;
        this.bound2y = bound2y;
        periodOnUpdates = period*Game.UPS_SET;
        calcUpdates();
    }

    private void calcUpdates(){
        xSpeed = (float) ((bound2x-bound1x)/periodOnUpdates);
        ySpeed = (float) ((bound2y-bound1y)/periodOnUpdates);
    }

    @Override
    public void update() {
        updatePos();
        updateHitbox();
    }
    private void updatePos(){
        if (x<=bound1x || x>=bound2x)
            xSpeed=xSpeed*-1;
        if (y<=bound1y || y>= bound2y)
            ySpeed=ySpeed*-1;
        x+=xSpeed;
        y+=ySpeed;
    }

    @Override
    public void render(Graphics g) {
        g.setColor(color);
        g.fillRect((int)x,(int)y,width,height);
    }

    public float getxSpeed() {
        return xSpeed;
    }

    public float getySpeed() {
        return ySpeed;
    }

}
