import javax.swing.*;
import java.awt.*;

public class GameSavedPopUp extends JFrame {
    public GameSavedPopUp() throws HeadlessException {
        super("SAVE");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(new Dimension(400,250));
        setLayout(null);
        JLabel label = new JLabel("KAYIT TAMAM");
        label.setBounds(new Rectangle(160,50,200,50));
        add(label);
        JButton button = new JButton("OK");
        button.setBounds(new Rectangle(100,100,200,100));
        button.addActionListener(e -> {
            dispose();
        });
        add(button);

        setLocationRelativeTo(null);
        setVisible(true);
    }


}
