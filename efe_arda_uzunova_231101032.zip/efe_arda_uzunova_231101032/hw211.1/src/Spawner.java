import java.awt.*;
import java.util.Random;

public class Spawner extends Entity{
    private int spawnRate =12;
    private int spawnRateInUpdates = spawnRate*Game.UPS_SET;
    private int updates = 0;
    Color spawnColor;
    Random random = new Random();
    public Spawner(float x, float y, int width, int height, Color color,Game game) {
        super(x, y, width, height, color,game);
    }
    @Override
    public void update() {
        updates++;
        if (updates >= spawnRateInUpdates){
            switch (random.nextInt(4)){
                case 1:
                    spawnColor = Color.RED;
                    break;
                case 2:
                    spawnColor = Color.BLUE;
                    break;
                case 3:
                    spawnColor = Color.ORANGE;
                    break;
            }
            game.addToArrayLists(new Enemy(x,y,width,height,spawnColor,game));
            updateHitbox();
            updates=0;
        }
    }
    @Override
    public void render(Graphics g) {
        g.setColor(color);
        g.fillRect( (int) x, (int) y, width, height);
    }
}
