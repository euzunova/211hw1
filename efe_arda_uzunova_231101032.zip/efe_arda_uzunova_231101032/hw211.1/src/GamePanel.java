import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;

public class GamePanel extends JPanel {
	private Game game;
	public GamePanel(Game game) {
		this.game = game;
		setPanelSize();
		addKeyListener(new KeyboardInputs(this));
	}
	private void setPanelSize() {
		Dimension size = new Dimension(Game.GAME_WIDTH, Game.GAME_HEIGHT);
		setPreferredSize(size);
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.BLACK);

		for (int i = 0; i < Level.getLeveldata().length; i++){
			for (int j = 0; j < Level.getLeveldata()[i].length; j++){

				if (Level.getLeveldata()[i][j]==Constants.MapColors.BLACK)
					g.setColor(Color.black);
				else if (Level.getLeveldata()[i][j]==Constants.MapColors.WHITE)
					g.setColor(Color.white);
				else if (Level.getLeveldata()[i][j]==Constants.MapColors.RED)
					g.setColor(Color.red);
				else if (Level.getLeveldata()[i][j]==Constants.MapColors.BLUE)
					g.setColor(Color.blue);

				g.fillRect(j * Game.TILES_SIZE, i * Game.TILES_SIZE, Game.TILES_SIZE, Game.TILES_SIZE);
			}
		}
		game.render(g);
	}
	public Game getGame() {
		return game;
	}

}