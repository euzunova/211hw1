import java.awt.*;

public class Enemy extends Entity{
    private float xSpeed = 0.7f;
    private int HP = 3;


    public Enemy(float x, float y, int width, int height, Color color,Game game) {
        super(x, y, width, height, color,game);
    }

    private void updateXPos(float xSpeed) {
        if (HelpMethods.CanMoveHere(hitbox.x+xSpeed,hitbox.y-1,hitbox.width,hitbox.height,lvlData)){
            this.x += xSpeed;
        }else
            this.xSpeed = xSpeed*-1;
    }
    private void updatePos() {

        if(!inAir){
            if(!HelpMethods.IsEntityOnFloor(hitbox,lvlData)){
                inAir = true;
            }
        }


        if (inAir) {
            if (HelpMethods.CanMoveHere(hitbox.x, hitbox.y + airSpeed,hitbox.width,hitbox.height, lvlData)) {
                updateXPos(xSpeed);
                y += airSpeed;
                airSpeed += gravity;

            }

            else {
                y = (int) HelpMethods.GetEntityYPos(hitbox, airSpeed);
                updateXPos(xSpeed);
                if (airSpeed > 0)
                    resetInAir();


            }
        }else
            updateXPos(xSpeed);
    }

    public void update() {
        if (HP<=0 && color != Color.ORANGE){
            game.RemoveFromArrayLists(this);
            game.addPoints(10);
        }

        updatePos();
        updateHitbox();
    }

    public void render(Graphics g) {
        g.setColor(color);
        g.fillRect( (int) x, (int) y, width, height);
    }

    private void resetInAir() {
        inAir = false;
        airSpeed = 0;
    }

    public void getHit(Color color){
        if (color == this.color)
            HP++;
        else
            HP--;
    }

}
