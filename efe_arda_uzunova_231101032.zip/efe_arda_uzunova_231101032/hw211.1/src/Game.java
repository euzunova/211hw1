import java.awt.*;
import java.io.*;
import java.util.ArrayList;


public class Game implements Runnable, Serializable {
	@Serial
	private static final long serialVersionUID = 6529685098267757690L;
	private transient GameWindow gameWindow;
	private transient GamePanel gamePanel;
	private transient Thread gameThread;
	public static final int FPS_SET = 120;
	public static final int UPS_SET = 200;
	private static boolean pause = false;

	public final static int TILES_DEFAULT_SIZE = 32;
	public final static float SCALE = 0.8f;
	public final static int TILES_IN_WIDTH = 26;
	public final static int TILES_IN_HEIGHT = 42;
	public final static int TILES_SIZE = (int) (TILES_DEFAULT_SIZE*SCALE);
	public final static int GAME_WIDTH = TILES_SIZE*TILES_IN_WIDTH;
	public final static int GAME_HEIGHT = TILES_SIZE*TILES_IN_HEIGHT;

	Player player;
	private ArrayList<Gold> golds = new ArrayList<Gold>();
	private ArrayList<Gold> goldsToRemove = new ArrayList<Gold>();
	private ArrayList<Enemy> enemies = new ArrayList<Enemy>();
	private ArrayList<Enemy> enemiesToRemove = new ArrayList<Enemy>();
	private ArrayList<Bullet> bullets = new ArrayList<Bullet>();
	private ArrayList<Bullet> bulletsToRemove = new ArrayList<Bullet>();
	private ArrayList<Platform> platforms = new ArrayList<Platform>();
	private ArrayList<Platform> platformsToRemove = new ArrayList<Platform>();
	private Spawner spawner = null;
	private Door door = null;
	int playerScore = 0;

	public Game() {
		initClasses();
		initPanel();
		startGameLoop();
	}
	public void initPanel(){
		gamePanel = new GamePanel(this);
		gameWindow = new GameWindow(gamePanel);
		gamePanel.requestFocus();
	}
	private void initClasses() {
		player = new Player(2*TILES_SIZE, 40*TILES_SIZE,TILES_SIZE/2,TILES_SIZE/2, Color.RED,this);

		enemies.add(new Enemy(7*TILES_SIZE, 21*TILES_SIZE,TILES_SIZE-1,TILES_SIZE-1, Color.RED,this));
		enemies.add(new Enemy(12*TILES_SIZE, 21*TILES_SIZE,TILES_SIZE-1,TILES_SIZE-1, Color.BLUE,this));
		enemies.add(new Enemy(9*TILES_SIZE, 24*TILES_SIZE,TILES_SIZE-1,TILES_SIZE-1, Color.ORANGE,this));
		enemies.add(new Enemy(7*TILES_SIZE, 28*TILES_SIZE,TILES_SIZE-1,TILES_SIZE-1, Color.BLUE,this));

		golds.add(new Gold(24*TILES_SIZE,40*TILES_SIZE,TILES_SIZE/4,TILES_SIZE/4,Color.YELLOW,this));
		golds.add(new Gold(23*TILES_SIZE,1*TILES_SIZE,TILES_SIZE/4,TILES_SIZE/4,Color.YELLOW,this));
		golds.add(new Gold(7*TILES_SIZE,6*TILES_SIZE,TILES_SIZE/4,TILES_SIZE/4,Color.YELLOW,this));
		golds.add(new Gold(8*TILES_SIZE,22*TILES_SIZE,TILES_SIZE/4,TILES_SIZE/4,Color.YELLOW,this));
		golds.add(new Gold(20*TILES_SIZE,18*TILES_SIZE,TILES_SIZE/4,TILES_SIZE/4,Color.YELLOW,this));

		spawner = new Spawner(11*TILES_SIZE, 9*TILES_SIZE,TILES_SIZE-1,TILES_SIZE-1, Color.CYAN,this);
		door = new Door(12*TILES_SIZE,3*TILES_SIZE-1,TILES_SIZE-1,TILES_SIZE-1,Color.PINK,this);

		platforms.add(new Platform(23*TILES_SIZE,11*TILES_SIZE+1,TILES_SIZE,TILES_SIZE/4,Color.WHITE,23*TILES_SIZE,9*TILES_SIZE,23*TILES_SIZE,21*TILES_SIZE,2,this));
		platforms.add(new Platform(3*TILES_SIZE,11*TILES_SIZE+1,TILES_SIZE,TILES_SIZE/4,Color.WHITE,23*TILES_SIZE,5*TILES_SIZE,23*TILES_SIZE,17*TILES_SIZE,2,this));

	}
	public void addToArrayLists(Entity entity){
		String className = entity.getClass().getName();
		switch (className){
			case "Gold":
				golds.add((Gold)entity);
				break;
			case "Enemy":
				enemies.add((Enemy) entity);
				break;
			case "Bullet":
				bullets.add((Bullet) entity);
				break;
		}
	}
	public void RemoveFromArrayLists(Entity entity){
		String className = entity.getClass().getName();
		switch (className){
			case "Gold":
				goldsToRemove.add((Gold)entity);
				break;
			case "Enemy":
				enemiesToRemove.add((Enemy) entity);
				break;
			case "Bullet":
				bulletsToRemove.add((Bullet) entity);
				break;
		}
	}
	public void GameOver() {
		pause=true;
		new GameEndPopUp(this);
		System.out.println("GAME OVER");
	}
	public void startGameLoop() {
		gameThread = new Thread(this);
		gameThread.start();
	}
	public void update() {
		if (!pause){
			player.update();

			for (Gold gold : golds){
				gold.update();
			}
			for (Gold gold : goldsToRemove){
				golds.remove(gold);
			}

			for (Enemy enemy : enemies){
				enemy.update();
			}
			for (Enemy enemy : enemiesToRemove){
				enemies.remove(enemy);
			}

			for (Bullet bullet : bullets){
				bullet.update();
			}
			for (Bullet bullet : bulletsToRemove){
				bullets.remove(bullet);
			}
			for (Platform platform : platforms){
				platform.update();
			}
			for (Platform platform : platformsToRemove){
				platforms.remove(platform);
			}
			spawner.update();
			door.update();
		}
	}
	public void render(Graphics g) {
		player.render(g);
		for (Gold gold : golds){
			gold.render(g);
		}
		for (Enemy enemy : enemies){
			enemy.render(g);
		}
		for (Bullet bullet : bullets){
			bullet.render(g);
		}
		for (Platform platform : platforms){
			platform.render(g);
		}
		spawner.render(g);
		door.render(g);

		g.setColor(Color.CYAN);
		g.setFont(new Font("Arial", Font.PLAIN, 24));
		g.drawString("Score: "+playerScore,0,TILES_SIZE);
	}
	@Override
	public void run() {

		double timePerFrame = 1000000000.0 / FPS_SET;
		double timePerUpdate = 1000000000.0 / UPS_SET;

		long previousTime = System.nanoTime();

		int frames = 0;
		int updates = 0;
		long lastCheck = System.currentTimeMillis();

		double deltaU = 0;
		double deltaF = 0;

		while (true) {
			long currentTime = System.nanoTime();

			deltaU += (currentTime - previousTime) / timePerUpdate;
			deltaF += (currentTime - previousTime) / timePerFrame;
			previousTime = currentTime;

			if (deltaU >= 1) {
				update();
				updates++;
				deltaU--;
			}

			if (deltaF >= 1) {
				gamePanel.repaint();
				frames++;
				deltaF--;
			}

			if (System.currentTimeMillis() - lastCheck >= 1000) {
				lastCheck = System.currentTimeMillis();
				System.out.println("FPS: " + frames + " | UPS: " + updates+" | POINTS: "+playerScore);
				frames = 0;
				updates = 0;

			}
		}

	}
	public void windowFocusLost() {
		player.resetDirBooleans();
	}
	public void addPoints(int points) {
		playerScore += points;
	}
	public void restart(){
		System.out.println("RESTART");
		for (Enemy enemy: enemies){
			enemiesToRemove.add(enemy);
		}
		for (Bullet bullet : bullets){
			bulletsToRemove.add(bullet);
		}
		for (Gold gold : golds){
			goldsToRemove.add(gold);
		}
		for (Platform platform : platforms){
			platformsToRemove.add(platform);
		}

		player=null;
		playerScore = 0;
		initClasses();
	}
	public void save(){
		if (pause){
			try {
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("save.txt"));
				objectOutputStream.writeObject(this);
			} catch (IOException e) {
                e.printStackTrace();
            }
			new GameSavedPopUp();

            System.out.println("SAVED");
		}

	}
	public void switchPause() {
		if(this.pause)
			this.pause=false;
		else
			this.pause=true;
	}
	public Player getPlayer() {
		return player;
	}
	public ArrayList<Enemy> getEnemies() {
		return enemies;
	}
	public ArrayList<Platform> getPlatforms() {
		return platforms;
	}
}