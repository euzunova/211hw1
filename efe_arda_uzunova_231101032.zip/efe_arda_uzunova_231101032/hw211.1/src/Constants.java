public class Constants {
	public static class Directions {
		public static final int LEFT = -1;
		public static final int RIGHT = 1;
	}
	public static class MapColors{
		public static final int BLACK = 0;
		public static final int WHITE = 1;
		public static final int RED = 2;
		public static final int BLUE = 3;
	}
}
