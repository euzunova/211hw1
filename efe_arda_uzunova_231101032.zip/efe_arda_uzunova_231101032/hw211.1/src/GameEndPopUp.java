import javax.swing.*;
import java.awt.*;

public class GameEndPopUp extends JFrame {
    Game game;
    public GameEndPopUp(Game game) throws HeadlessException {
        super("YOU WON");
        this.game = game;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(new Dimension(400,250));
        setLayout(null);
        JLabel label = new JLabel("Score: "+game.playerScore);
        label.setBounds(new Rectangle(175,50,200,50));
        add(label);
        JButton button = new JButton("OK");
        button.setBounds(new Rectangle(100,100,200,100));
        button.addActionListener(e -> {
            dispose();
        });
        add(button);

        setLocationRelativeTo(null);
        setVisible(true);
    }


}
