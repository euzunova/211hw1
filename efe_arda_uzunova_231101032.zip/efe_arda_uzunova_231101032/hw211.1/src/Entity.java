import java.awt.*;
import java.io.Serializable;

public abstract class Entity implements Serializable {
	
	protected float x,y;
	protected int width,height;
	protected Rectangle hitbox;
	protected Color color;
	protected float gravity = 0.04f*Game.SCALE;
	protected boolean inAir;
	protected int [][] lvlData;
	protected float airSpeed = 0f;
	protected float entitySpeed ;
	protected Game game;
	public Entity(float x, float y, int width, int height, Color color, Game game) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
		this.game = game;

		initHitbox();
		loadLvlData(Level.getLeveldata());
	}
	public abstract void update();
	public abstract void render(Graphics g);
	private void initHitbox(){
		hitbox = new Rectangle((int) x,(int) y,width,height);
	}
	public void updateHitbox(){
		hitbox.x = (int) x;
		hitbox.y = (int) y;
	}
	public Rectangle getHitbox(){
		return hitbox;
	}
	public void loadLvlData(int[][] lvlData){
		this.lvlData = lvlData;
		if(!HelpMethods.IsEntityOnFloor(hitbox,lvlData))
			inAir=true;
	}
	public void setEntitySpeed(float entitySpeed) {
		this.entitySpeed = entitySpeed;
	}
}
