import java.awt.*;
import java.util.ArrayList;

public class HelpMethods {
    public static boolean CanMoveHere(float x, float y,int width,int height, int [][] lvlData){
        if (!IsSolid(x,y,lvlData)){
            if (!IsSolid(x+width,y+height,lvlData)){
                if (!IsSolid(x+width,y,lvlData)){
                    if (!IsSolid(x,y+height,lvlData)){
                        return true;
                    }
                }
            }
        }
        return false;
    }
    private static boolean IsSolid(float x, float y, int [][] lvlData){
        if (x < 0 || x >= Game.GAME_WIDTH){
            return true;
        }
        if (y < 0 || y >= Game.GAME_HEIGHT){
            return true;
        }
        int value = getColorAt(x,y,Level.getLeveldata());
        return value != Constants.MapColors.BLACK;
    }
    public static float GetEntityYPos(Rectangle hitbox, float airSpeed){
        int currentTile = hitbox.y / Game.TILES_SIZE;
        if(airSpeed>0){
            int tileYPos =currentTile*Game.TILES_SIZE;
            int yOffset = Game.TILES_SIZE - hitbox.height;
            return tileYPos+yOffset-1;
        }else {
            return currentTile * Game.TILES_SIZE;
        }
    }
    public static boolean IsEntityOnFloor(Rectangle hitbox,int[][] lvlData){
        if(!IsSolid(hitbox.x, hitbox.y+hitbox.height + 1,lvlData))
            if(!IsSolid(hitbox.x+hitbox.width, hitbox.y+hitbox.height + 1,lvlData))
                return false;
        return true;

    }
    public static Enemy CollidedEnemy(Entity entity, ArrayList<Enemy> enemies){
        for (Enemy enemy : enemies){
            if (DoesCollide(entity,enemy))
                            return enemy;
        }
        return null;
    }
    public static Platform CollidedPlatform(Entity entity, ArrayList<Platform> platforms){
        for (Platform platform : platforms){
            if (DoesCollide(entity,platform))
                return platform;
        }
        return null;
    }
    public static boolean DoesCollide(Entity entity1,Entity entity2){
        return entity1.getHitbox().intersects(entity2.getHitbox());
    }
    public static boolean onBlue(Rectangle hitbox, int[][] lvlData){
        return getColorAt(hitbox.x, hitbox.y + hitbox.height + 1, Level.getLeveldata()) == Constants.MapColors.BLUE || getColorAt(hitbox.x + hitbox.width, hitbox.y + hitbox.height + 1, Level.getLeveldata()) == Constants.MapColors.BLUE;
    }
    public static boolean onRed(Rectangle hitbox, int[][] lvlData){
        return getColorAt(hitbox.x, hitbox.y + hitbox.height + 1, Level.getLeveldata()) == Constants.MapColors.RED || getColorAt(hitbox.x + hitbox.width, hitbox.y + hitbox.height + 1, Level.getLeveldata()) == Constants.MapColors.RED;
    }
    public static int getColorAt(float x,float y, int[][] lvlData){
        float xIndex = x/Game.TILES_SIZE;
        float yIndex = y/Game.TILES_SIZE;
        return lvlData[(int) yIndex][(int) xIndex];
    }
}
