import java.awt.*;

public class Door extends Entity{
    public Door(float x, float y, int width, int height, Color color,Game game) {
        super(x, y, width, height, color,game);
    }

    @Override
    public void update() {
        if (HelpMethods.DoesCollide(this,game.getPlayer())){
            game.GameOver();
        }
    }

    @Override
    public void render(Graphics g) {
        g.setColor(color);
        g.fillRect((int) x,(int) y,width,height);
    }
}
